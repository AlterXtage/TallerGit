Segui paso a paso lo que el archivo pedia 
Inicialmente pense en hacerlo con un amigo del curso hermano de Desarrollo 2
Ya que de esa forma si teniamos alguna duda podriamos solucionarlo de manera colaborativa y terminariamos mas rapido, esto result ser beneficioso ya que mi pc originalmente si presento un par de problemas, afortunadamente notifique los problemas el dia 06 de octubre de 2024
ya investigando bastante logramos deducir como hacerlo funcionar en mi pc y aqui es donde empezamos:

-Primero cree la carpeta llamada Proyecto
-Luego utilice el commando cd para poder especificar el directorio en el cual estaba trabajando
- Procedi con normalidad especificando mi nombre y mi correo
- Cree la branch feature  
- Empece a escribir cosas dentro de un archivo de texto llamado archivo.txt, le puse un poco de personalidad a los textos para que no se hiciera tan mundane leerlos 
- hice lo mismo con los commits hechos en feature, la rama que habia creado
-Luego cambie a master
-Modifiqué el mismo archivo conflicto.txt, pero con un contenido diferente.
-Intenté hacer un commit, pero de nuevo me olvidé de agregar el archivo. Lo añadí y el commit se completó sin problemas.

-El siguiente paso era fusionar los cambios de feature en master. Pero al hacer el merge, me encontre con un conflicto porque el archivo conflicto.txt habia sido modificado en ambas ramas. Git no pudo hacer la fusion automaticamente y me aviso del conflicto.

-Revise el archivo y resolvi manualmente el conflicto
